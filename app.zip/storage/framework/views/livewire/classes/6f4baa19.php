<?php

use Livewire\Component;

return new class extends Component
{
    public function render()
    {
        return view('pages::admin.⚡dashboard')
            ->layout('layouts::app')->title('Admin Dashboard');
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\xampp\htdocs\novibe\laravel\storage\framework/views/livewire/views/6f4baa19.blade.php', $data);
    }
};
