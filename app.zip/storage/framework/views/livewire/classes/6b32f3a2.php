<?php

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Ekstrakurikuler;
use App\Models\Vote;
use Illuminate\Validation\Rule;

return new class extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    // Properties untuk form
    public $showForm = false;
    public $formType = 'create'; // 'create' or 'edit'
    public $ekstraId = null;

    public $nama = '';
    public $deskripsi = '';
    public $pembina = '';
    public $kuota = 30;

    // Properties untuk search
    public $search = '';
    public $filterStatus = '';

    
    // Properties untuk statistik
    public $stats = [];
    
    // Properties untuk delete
   public $deleteId = null;
   public $deleteName = '';

    protected function rules()
    {
        $rules = [
            'nama' => 'required|string|max:255',
            'deskripsi' => 'required|string|min:10',
            'pembina' => 'required|string|max:255',
            'kuota' => 'required|integer|min:1|max:200',
        ];

        // Untuk edit, tambahkan rule unique kecuali untuk data yang sedang diedit
        if ($this->formType === 'edit') {
            $rules['nama'] = [
                'required',
                'string',
                'max:255',
                Rule::unique('ekstrakurikulers')->ignore($this->ekstraId)
            ];
        } else {
            $rules['nama'] = 'required|string|max:255|unique:ekstrakurikulers,nama';
        }

        return $rules;
    }

    protected $messages = [
        'nama.required' => 'Nama ekstrakurikuler wajib diisi.',
        'nama.unique' => 'Nama ekstrakurikuler sudah ada.',
        'deskripsi.required' => 'Deskripsi wajib diisi.',
        'deskripsi.min' => 'Deskripsi minimal 10 karakter.',
        'pembina.required' => 'Nama pembina wajib diisi.',
        'kuota.required' => 'Kuota wajib diisi.',
        'kuota.integer' => 'Kuota harus berupa angka.',
        'kuota.min' => 'Kuota minimal 1 peserta.',
        'kuota.max' => 'Kuota maksimal 200 peserta.',
    ];

    public function mount()
    {
        $this->loadStats();
    }

    private function loadStats()
    {
        $this->stats = [
            'total' => Ekstrakurikuler::count(),
            'totalKuota' => Ekstrakurikuler::sum('kuota'),
            'totalPemilih' => Vote::count(),
            'persentaseTerisi' => Ekstrakurikuler::sum('kuota') > 0 ? 
                round((Vote::count() / Ekstrakurikuler::sum('kuota')) * 100, 1) : 0,
        ];
    }

    // Reset form
    private function resetForm()
    {
        $this->reset([
            'nama', 'deskripsi', 'pembina', 'kuota',
            'showForm', 'formType', 'ekstraId'
        ]);
        $this->resetErrorBag();
        $this->kuota = 30; // Reset ke default
    }

    // Show create form
    public function showCreateForm()
    {
        $this->resetForm();
        $this->formType = 'create';
        $this->showForm = true;
    }

    // Show edit form
    public function showEditForm($id)
    {
        $this->resetForm();
        
        $ekstra = Ekstrakurikuler::findOrFail($id);
        $this->ekstraId = $ekstra->id;
        $this->nama = $ekstra->nama;
        $this->deskripsi = $ekstra->deskripsi;
        $this->pembina = $ekstra->pembina;
        $this->kuota = $ekstra->kuota;
        
        $this->formType = 'edit';
        $this->showForm = true;
    }

    // Save data
    public function save()
    {
        $this->validate();

        $data = [
            'nama' => $this->nama,
            'deskripsi' => $this->deskripsi,
            'pembina' => $this->pembina,
            'kuota' => $this->kuota,
        ];

        if ($this->formType === 'create') {
            Ekstrakurikuler::create($data);
            $message = 'Ekstrakurikuler berhasil ditambahkan!';
        } else {
            Ekstrakurikuler::find($this->ekstraId)->update($data);
            $message = 'Ekstrakurikuler berhasil diperbarui!';
        }

        $this->resetForm();
        $this->loadStats();
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => $message
        ]);
    }

     // Delete data dengan form submit
    public function deleteEkstrakurikuler($id)
    {
        try {
            $ekstra = Ekstrakurikuler::findOrFail($id);
            $nama = $ekstra->nama;
            
            // Cek apakah ada siswa yang sudah memilih ekstrakurikuler ini
            if ($ekstra->votes()->count() > 0) {
                session()->flash('message', "Tidak dapat menghapus {$nama} karena sudah ada siswa yang memilih.");
                session()->flash('messageType', 'error');
                return;
            }
            
            $ekstra->delete();
            
            $this->loadStats();
            
            session()->flash('message', "Ekstrakurikuler {$nama} berhasil dihapus.");
            session()->flash('messageType', 'success');
            
        } catch (\Exception $e) {
            session()->flash('message', 'Terjadi kesalahan saat menghapus data.');
            session()->flash('messageType', 'error');
        }
    }

    // Cancel form
    public function cancel()
    {
        $this->resetForm();
    }

    // Get filtered data
    public function getEkstrakurikulersProperty()
    {
        return Ekstrakurikuler::query()
            ->withCount('votes')
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('nama', 'like', '%' . $this->search . '%')
                      ->orWhere('pembina', 'like', '%' . $this->search . '%')
                      ->orWhere('deskripsi', 'like', '%' . $this->search . '%');
                });
            })
            ->when($this->filterStatus, function ($query) {
                if ($this->filterStatus === 'penuh') {
                    $query->havingRaw('votes_count >= kuota');
                } elseif ($this->filterStatus === 'tersedia') {
                    $query->havingRaw('votes_count < kuota AND votes_count > 0');
                } elseif ($this->filterStatus === 'kosong') {
                    $query->havingRaw('votes_count = 0');
                } elseif ($this->filterStatus === 'hampir_penuh') {
                    $query->havingRaw('votes_count >= kuota * 0.8 AND votes_count < kuota');
                }
            })
            ->orderBy('nama')
            ->paginate(10);
    }

    // Hitung persentase kuota
    public function getPersentaseKuota($ekstra)
    {
        if ($ekstra->kuota == 0) return 0;
        
        $pemilih = $ekstra->votes_count;
        return round(($pemilih / $ekstra->kuota) * 100, 1);
    }

    // Get status kuota
    public function getStatusKuota($ekstra)
    {
        $persentase = $this->getPersentaseKuota($ekstra);
        
        if ($persentase >= 100) {
            return ['label' => 'Penuh', 'color' => 'danger', 'icon' => 'bi-x-circle'];
        } elseif ($persentase >= 80) {
            return ['label' => 'Hampir Penuh', 'color' => 'warning', 'icon' => 'bi-exclamation-triangle'];
        } elseif ($ekstra->votes_count > 0) {
            return ['label' => 'Tersedia', 'color' => 'success', 'icon' => 'bi-check-circle'];
        } else {
            return ['label' => 'Belum Ada Pemilih', 'color' => 'secondary', 'icon' => 'bi-clock'];
        }
    }

    // Get sisa kuota
    public function getSisaKuota($ekstra)
    {
        return max(0, $ekstra->kuota - $ekstra->votes_count);
    }

    // Refresh data
    public function refreshData()
    {
        $this->loadStats();
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Data telah diperbarui.'
        ]);
    }

    public function render()
    {
        return view('pages::admin.⚡ekstramanage', [
            'ekstrakurikulers' => $this->ekstrakurikulers,
        ])->layout('layouts::app')->title('Kelola Ekstrakurikuler');
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\xampp\htdocs\novibe\laravel\storage\framework/views/livewire/views/6b32f3a2.blade.php', $data);
    }

    public function scriptModuleSrc()
    {
        return 'C:\xampp\htdocs\novibe\laravel\storage\framework/views/livewire/scripts/6b32f3a2.js';
    }

    public function styleModuleSrc()
    {
        return 'C:\xampp\htdocs\novibe\laravel\storage\framework/views/livewire/styles/6b32f3a2.css';
    }
};
