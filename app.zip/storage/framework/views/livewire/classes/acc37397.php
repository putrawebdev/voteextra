<?php

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\User;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;

return new class extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    // Properties untuk form
    public $showDeleteModal = false;  
    public $showForm = false;
    public $formType = 'create'; // 'create' or 'edit'
    public $userId = null;

    public $name = '';
    public $email = '';
    public $nisn = '';
    public $kelas = '';
    public $jurusan = '';
    public $password = '';
    public $password_confirmation = '';
    public $role = 'siswa';
    public $status = true;
    public $has_voted = false;

    // Properties untuk search dan filter
    public $search = '';
    public $filterKelas = '';
    public $filterJurusan = '';
    public $filterRole = '';
    public $filterStatus = '';
    public $filterVoted = '';

    // Properties untuk statistik
    public $stats = [];

    // Properties untuk delete
    public $deleteId = null;
    public $deleteName = '';
    public $deleteNisn = '';
    public $deleteClass = '';

    // List kelas dan jurusan
    public $kelasList = [
        '10' => ['X PPLG', 'X DKV', 'X Kuliner'],
        '11' => ['XI PPLG', 'XI DKV', 'XI Kuliner'],
        '12' => ['XII PPLG', 'XII DKV', 'XII Kuliner'],
    ];

    public $jurusanList = [
        'PPLG' => 'Pengembangan Perangkat Lunak dan Gim',
        'DKV' => 'Desain Komunikasi Visual',
        'Kuliner' => 'Kuliner',
        'UMUM' => 'Umum', // Untuk admin/staff
    ];

    protected function rules()
    {
        $rules = [
            'name' => 'required|string|max:255',
            'nisn' => 'required|string|max:20',
            'kelas' => 'required|string|max:20',
            'jurusan' => 'required|string|max:50',
            'email' => 'nullable|email|max:255',
            'role' => 'required|in:siswa,admin',
            'status' => 'required|boolean',
            'has_voted' => 'boolean',
        ];

        // Validasi NISN unik untuk create
        if ($this->formType === 'create') {
            $rules['nisn'] = [
                'required',
                'string',
                'max:20',
                Rule::unique('users', 'nisn')
            ];
            $rules['password'] = 'required|string|min:8|confirmed';
        } else {
            // Untuk edit, NISN unik kecuali untuk user yang sedang diedit
            $rules['nisn'] = [
                'required',
                'string',
                'max:20',
                Rule::unique('users', 'nisn')->ignore($this->userId)
            ];
            
            // Password optional untuk edit
            if ($this->password) {
                $rules['password'] = 'string|min:8|confirmed';
            }
        }

        // Validasi email unik jika diisi
        if ($this->email) {
            $rules['email'] = [
                'nullable',
                'email',
                'max:255',
                Rule::unique('users', 'email')->ignore($this->userId)
            ];
        }

        return $rules;
    }

    protected $messages = [
        'name.required' => 'Nama wajib diisi.',
        'nisn.required' => 'NISN wajib diisi.',
        'nisn.unique' => 'NISN sudah terdaftar.',
        'kelas.required' => 'Kelas wajib diisi.',
        'jurusan.required' => 'Jurusan wajib dipilih.',
        'email.email' => 'Format email tidak valid.',
        'email.unique' => 'Email sudah terdaftar.',
        'password.required' => 'Password wajib diisi.',
        'password.min' => 'Password minimal 8 karakter.',
        'password.confirmed' => 'Konfirmasi password tidak sesuai.',
        'role.required' => 'Role wajib dipilih.',
        'status.required' => 'Status wajib dipilih.',
    ];

    public function mount()
    {
        $this->loadStats();
    }

    private function loadStats()
    {
        $this->stats = [
            'total' => User::count(),
            'siswa' => User::where('role', 'siswa')->count(),
            'admin' => User::where('role', 'admin')->count(),
            'active' => User::where('status', true)->count(),
            'inactive' => User::where('status', false)->count(),
            'hasVoted' => User::where('has_voted', true)->count(),
            'notVoted' => User::where('has_voted', false)->count(),
        ];
    }

    // Reset form
    private function resetForm()
    {
        $this->reset([
            'name', 'email', 'nisn', 'kelas', 'jurusan',
            'password', 'password_confirmation', 'role', 'status', 'has_voted',
            'showForm', 'formType', 'userId'
        ]);
        $this->resetErrorBag();
        $this->role = 'siswa';
        $this->status = true;
        $this->has_voted = false;
    }

    // Show create form
    public function showCreateForm()
    {
        $this->resetForm();
        $this->formType = 'create';
        $this->showForm = true;
    }

    // Show edit form
    public function showEditForm($id)
    {
        $this->resetForm();
        
        $user = User::findOrFail($id);
        $this->userId = $user->id;
        $this->name = $user->name;
        $this->email = $user->email;
        $this->nisn = $user->nisn;
        $this->kelas = $user->kelas;
        $this->jurusan = $user->jurusan;
        $this->role = $user->role;
        $this->status = (bool) $user->status;
        $this->has_voted = (bool) $user->has_voted;
        
        $this->formType = 'edit';
        $this->showForm = true;
    }

    // Save data
    public function save()
    {
        $this->validate();

        $data = [
            'name' => $this->name,
            'email' => $this->email,
            'nisn' => $this->nisn,
            'kelas' => $this->kelas,
            'jurusan' => $this->jurusan,
            'role' => $this->role,
            'status' => $this->status,
            'has_voted' => $this->has_voted,
        ];

        // Jika password diisi (untuk create atau edit dengan password baru)
        if ($this->password) {
            $data['password'] = Hash::make($this->password);
        }

        if ($this->formType === 'create') {
            // Untuk create, pastikan email_verified_at diisi jika ada email
            if ($this->email) {
                $data['email_verified_at'] = now();
            }
            
            User::create($data);
            $message = 'User berhasil ditambahkan!';
        } else {
            // Untuk edit, jika password tidak diubah, jangan update password
            if (!$this->password) {
                unset($data['password']);
            }
            
            User::find($this->userId)->update($data);
            $message = 'User berhasil diperbarui!';
        }

        $this->resetForm();
        $this->loadStats();
        
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => $message
        ]);
    }

    // Reset password
    public function resetPassword($id)
    {
        $user = User::findOrFail($id);
        $defaultPassword = Hash::make('password123'); // Default password
        
        $user->update(['password' => $defaultPassword]);
        
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => "Password {$user->name} telah direset ke default (password123)"
        ]);
    }

    // Toggle status
    public function toggleStatus($id)
    {
        $user = User::findOrFail($id);
        $user->update(['status' => !$user->status]);
        
        $status = $user->status ? 'diaktifkan' : 'dinonaktifkan';
        $this->loadStats();
        
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => "Status {$user->name} telah {$status}"
        ]);
    }

    // Toggle voting status
    public function toggleVoteStatus($id)
    {
        $user = User::findOrFail($id);
        $user->update(['has_voted' => !$user->has_voted]);
        
        $status = $user->has_voted ? 'ditandai sudah voting' : 'ditandai belum voting';
        $this->loadStats();
        
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => "Status voting {$user->name} telah {$status}"
        ]);
    }

    
    // CONFIRM DELETE
    public function confirmDelete($id)
    {
        $user = User::findOrFail($id);
        
        if ($user->has_voted) {
            session()->flash('error', "Tidak dapat menghapus {$user->name} karena sudah melakukan voting.");
            return;
        }
        
        $this->deleteId = $user->id;
        $this->deleteName = $user->name;
        $this->deleteNisn = $user->nisn;
        $this->deleteClass = $user->kelas;
        
        $this->showDeleteModal = true;
    }

    // DELETE USER
    public function deleteUser()
    {
        if (!$this->deleteId) {
            session()->flash('error', 'ID user tidak valid.');
            return;
        }

        try {
            $user = User::findOrFail($this->deleteId);
            
            if ($user->has_voted) {
                session()->flash('error', "Tidak dapat menghapus {$user->name} karena sudah melakukan voting.");
                $this->closeDeleteModal();
                return;
            }
            
            $userName = $user->name;
            $user->delete();
            
            $this->loadStats();
            $this->closeDeleteModal();
            
            session()->flash('success', "User {$userName} berhasil dihapus.");
            
        } catch (\Exception $e) {
            session()->flash('error', 'Terjadi kesalahan saat menghapus data: ' . $e->getMessage());
            $this->closeDeleteModal();
        }
    }

    // CLOSE DELETE MODAL
    public function closeDeleteModal()
    {
        $this->showDeleteModal = false;
        $this->deleteId = null;
        $this->deleteName = '';
        $this->deleteNisn = '';
        $this->deleteClass = '';
    }


    // Cancel form
    public function cancel()
    {
        $this->resetForm();
    }

    // Get filtered data
    public function getUsersProperty()
    {
        return User::query()
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('nisn', 'like', '%' . $this->search . '%')
                      ->orWhere('name', 'like', '%' . $this->search . '%')
                      ->orWhere('email', 'like', '%' . $this->search . '%')
                      ->orWhere('kelas', 'like', '%' . $this->search . '%');
                });
            })
            ->when($this->filterKelas, function ($query) {
                $query->where('kelas', 'like', $this->filterKelas . '%');
            })
            ->when($this->filterJurusan, function ($query) {
                $query->where('jurusan', $this->filterJurusan);
            })
            ->when($this->filterRole, function ($query) {
                $query->where('role', $this->filterRole);
            })
            ->when($this->filterStatus !== '', function ($query) {
                $query->where('status', $this->filterStatus == '1');
            })
            ->when($this->filterVoted !== '', function ($query) {
                $query->where('has_voted', $this->filterVoted == '1');
            })
            ->orderBy('kelas')
            ->orderBy('name')
            ->paginate(15);
    }

    // Get kelas options berdasarkan filter
    public function getFilteredKelasOptionsProperty()
    {
        $options = [];
        foreach ($this->kelasList as $tingkat => $kelasArr) {
            foreach ($kelasArr as $kelas) {
                $options[$kelas] = $kelas;
            }
        }
        return $options;
    }

    // Refresh data
    public function refreshData()
    {
        $this->loadStats();
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Data telah diperbarui.'
        ]);
    }

    // Export data
    public function exportData()
    {
        $this->dispatch('swal', [
            'icon' => 'info',
            'title' => 'Info',
            'text' => 'Fitur export akan segera tersedia.'
        ]);
    }

    // Import data
    public function importData()
    {
        $this->dispatch('swal', [
            'icon' => 'info',
            'title' => 'Info',
            'text' => 'Fitur import akan segera tersedia.'
        ]);
    }

    // Bulk actions
    public function bulkResetPassword()
    {
        $this->dispatch('swal', [
            'icon' => 'info',
            'title' => 'Info',
            'text' => 'Fitur reset password massal akan segera tersedia.'
        ]);
    }

    public function render()
    {
        return view('pages::admin.⚡usermanage', [
            'users' => $this->users,
        ])->layout('layouts.app')->title('Kelola User');
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\xampp\htdocs\novibe\laravel\storage\framework/views/livewire/views/acc37397.blade.php', $data);
    }

    public function scriptModuleSrc()
    {
        return 'C:\xampp\htdocs\novibe\laravel\storage\framework/views/livewire/scripts/acc37397.js';
    }

    public function styleModuleSrc()
    {
        return 'C:\xampp\htdocs\novibe\laravel\storage\framework/views/livewire/styles/acc37397.css';
    }
};

