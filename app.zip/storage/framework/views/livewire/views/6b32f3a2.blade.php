<?php
use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Ekstrakurikuler;
use App\Models\Vote;
use Illuminate\Validation\Rule;
?>

<div>
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex p-3 justify-content-between align-items-center">
                <div>
                    <h2 class="fw-bold">
                        <i class="bi bi-trophy"></i> Kelola Ekstrakurikuler
                    </h2>
                    <p class="text-muted">Management data ekstrakurikuler SMK Metland Cibitung</p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary" wire:click="refreshData">
                        <i class="bi bi-arrow-clockwise"></i> Refresh
                    </button>
                    <button class="btn btn-primary" wire:click="showCreateForm">
                        <i class="bi bi-plus-circle"></i> Tambah Ekstrakurikuler
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats -->
    <div class="row mb-4 p-3">
        <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Ekstrakurikuler</h6>
                            <h2 class="mb-0">{{ $stats['total'] ?? 0 }}</h2>
                        </div>
                        <i class="bi bi-collection" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Kuota</h6>
                            <h2 class="mb-0">{{ $stats['totalKuota'] ?? 0 }}</h2>
                        </div>
                        <i class="bi bi-people-fill" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Pemilih</h6>
                            <h2 class="mb-0">{{ $stats['totalPemilih'] ?? 0 }}</h2>
                        </div>
                        <i class="bi bi-check-circle-fill" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Terisi</h6>
                            <h2 class="mb-0">{{ $stats['persentaseTerisi'] ?? 0 }}%</h2>
                        </div>
                        <i class="bi bi-percent" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search and Filter -->
    <div class="card mb-2 shadow-sm">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-search"></i>
                        </span>
                        <input type="text" 
                               class="form-control" 
                               placeholder="Cari nama, pembina, atau deskripsi..." 
                               wire:model.live.debounce.300ms="search">
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select" wire:model.live="filterStatus">
                        <option value="">Semua Status</option>
                        <option value="tersedia">Tersedia</option>
                        <option value="hampir_penuh">Hampir Penuh</option>
                        <option value="penuh">Penuh</option>
                        <option value="kosong">Belum Ada Pemilih</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <div class="d-flex justify-content-end">
                        <span class="text-muted me-2">
                            {{ $ekstrakurikulers->total() }} data ditemukan
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Form Modal -->
    @if($showForm)
        <!-- Delete Confirmation Modal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" wire:ignore.self>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title">
                            <i class="bi bi-exclamation-triangle"></i> Konfirmasi Hapus
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah Anda yakin ingin menghapus <strong id="deleteItemName"></strong>?</p>
                        <p class="text-danger small">
                            <i class="bi bi-info-circle"></i> 
                            Data yang sudah dihapus tidak dapat dikembalikan.
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-circle"></i> Batal
                        </button>
                        <button type="button" class="btn btn-danger" id="confirmDeleteBtn">
                            <i class="bi bi-trash"></i> Ya, Hapus
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">
                            <i class="bi bi-trophy"></i>
                            {{ $formType === 'create' ? 'Tambah' : 'Edit' }} Ekstrakurikuler
                        </h5>
                        <button type="button" class="btn-close btn-close-white" wire:click="cancel"></button>
                    </div>
                    <div class="modal-body">
                        <form wire:submit.prevent="save">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nama Ekstrakurikuler <span class="text-danger">*</span></label>
                                    <input type="text" 
                                           class="form-control @error('nama') is-invalid @enderror" 
                                           wire:model="nama"
                                           placeholder="Contoh: Pramuka, PMR, Basket"
                                           autofocus>
                                    @error('nama') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Pembina <span class="text-danger">*</span></label>
                                    <input type="text" 
                                           class="form-control @error('pembina') is-invalid @enderror" 
                                           wire:model="pembina"
                                           placeholder="Nama pembina">
                                    @error('pembina') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Deskripsi <span class="text-danger">*</span></label>
                                <textarea class="form-control @error('deskripsi') is-invalid @enderror" 
                                          wire:model="deskripsi" 
                                          rows="4"
                                          placeholder="Deskripsi kegiatan ekstrakurikuler..."></textarea>
                                @error('deskripsi') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                <small class="text-muted">Minimal 10 karakter</small>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Kuota Peserta <span class="text-danger">*</span></label>
                                    <input type="number" 
                                           class="form-control @error('kuota') is-invalid @enderror" 
                                           wire:model="kuota"
                                           min="1" 
                                           max="200">
                                    @error('kuota') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                    <small class="text-muted">Maksimal 200 peserta</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Preview</label>
                                    <div class="border rounded p-3 bg-light">
                                        <small class="text-muted d-block mb-1">Informasi:</small>
                                        <div class="d-flex justify-content-between">
                                            <span>Nama:</span>
                                            <span class="fw-semibold">{{ $nama ?: 'Belum diisi' }}</span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <span>Kuota:</span>
                                            <span class="fw-semibold">{{ $kuota }} peserta</span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <span>Pembina:</span>
                                            <span class="fw-semibold">{{ $pembina ?: 'Belum diisi' }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2 mt-4">
                                <button type="button" class="btn btn-secondary" wire:click="cancel">
                                    <i class="bi bi-x-circle"></i> Batal
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Simpan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <!-- Data Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            @if($ekstrakurikulers->isEmpty())
                <div class="text-center py-5">
                    <i class="bi bi-trophy" style="font-size: 4rem; color: #e9ecef;"></i>
                    <h4 class="mt-3">Tidak ada data</h4>
                    <p class="text-muted">Belum ada data ekstrakurikuler.</p>
                    <button class="btn btn-primary" wire:click="showCreateForm">
                        <i class="bi bi-plus-circle"></i> Tambah Data Pertama
                    </button>
                </div>
            @else
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th width="50">#</th>
                                <th>Nama Ekstrakurikuler</th>
                                <th>Pembina</th>
                                <th>Kuota</th>
                                <th>Pemilih</th>
                                <th>Status</th>
                                <th width="120" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($ekstrakurikulers as $index => $ekstra)
                                @php
                                    $status = $this->getStatusKuota($ekstra);
                                    $persentase = $this->getPersentaseKuota($ekstra);
                                    $sisaKuota = $this->getSisaKuota($ekstra);
                                @endphp
                                <tr>
                                    <td>{{ $ekstrakurikulers->firstItem() + $index }}</td>
                                    <td>
                                        <div>
                                            <strong class="d-block">{{ $ekstra->nama }}</strong>
                                            <small class="text-muted">{{ Str::limit($ekstra->deskripsi, 60) }}</small>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-info bg-opacity-10 text-info border border-info">
                                            {{ $ekstra->pembina }}
                                        </span>
                                    </td>
                                    <td>
                                        <div>
                                            <span class="fw-semibold">{{ $ekstra->kuota }}</span>
                                            <small class="text-muted d-block">peserta</small>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="progress flex-grow-1 me-2" style="height: 8px; min-width: 60px;">
                                                <div class="progress-bar bg-{{ $status['color'] }}" 
                                                     role="progressbar" 
                                                     style="width: {{ min($persentase, 100) }}%">
                                                </div>
                                            </div>
                                            <div class="text-end">
                                                <span class="fw-semibold">{{ $ekstra->votes_count }}</span>
                                                <small class="text-muted d-block">{{ $persentase }}%</small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-{{ $status['color'] }}">
                                            <i class="{{ $status['icon'] }} me-1"></i>{{ $status['label'] }}
                                        </span>
                                        @if($sisaKuota > 0 && $persentase < 100)
                                            <small class="d-block text-muted">Sisa: {{ $sisaKuota }}</small>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" 
                                                    wire:click="showEditForm({{ $ekstra->id }})"
                                                    title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            @if($ekstra->votes_count == 0)
                                                <form wire:submit.prevent="deleteEkstrakurikuler({{ $ekstra->id }})" 
                                                    onsubmit="return confirm('Apakah Anda yakin ingin menghapus {{ $ekstra->nama }}?')"
                                                    style="display: inline;">
                                                    @csrf
                                                    <button type="submit" 
                                                            class="btn btn-outline-danger" 
                                                            title="Hapus">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            @else
                                                <button class="btn btn-outline-secondary" 
                                                        title="Tidak dapat dihapus karena sudah ada pemilih"
                                                        disabled>
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            @endif
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <p class="text-muted mb-0">
                            Menampilkan {{ $ekstrakurikulers->firstItem() }} - {{ $ekstrakurikulers->lastItem() }} 
                            dari {{ $ekstrakurikulers->total() }} data
                        </p>
                    </div>
                    <div>
                        {{ $ekstrakurikulers->links() }}
                    </div>
                </div>
            @endif
        </div>
    </div>

    <!-- Legend and Information -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-info">
                <div class="card-header bg-info bg-opacity-10 border-info">
                    <h5 class="mb-0">
                        <i class="bi bi-info-circle text-info"></i> Informasi & Panduan
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-success me-2">
                                    <i class="bi bi-check-circle"></i> Tersedia
                                </span>
                                <div>
                                    <small class="fw-semibold">Tersedia</small>
                                    <p class="text-muted small mb-0">Masih menerima peserta baru</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-warning me-2">
                                    <i class="bi bi-exclamation-triangle"></i> Hampir Penuh
                                </span>
                                <div>
                                    <small class="fw-semibold">Hampir Penuh</small>
                                    <p class="text-muted small mb-0">Kuota terisi ≥80%</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-danger me-2">
                                    <i class="bi bi-x-circle"></i> Penuh
                                </span>
                                <div>
                                    <small class="fw-semibold">Penuh</small>
                                    <p class="text-muted small mb-0">Kuota sudah terpenuhi</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-secondary me-2">
                                    <i class="bi bi-clock"></i> Belum Ada
                                </span>
                                <div>
                                    <small class="fw-semibold">Belum Ada Pemilih</small>
                                    <p class="text-muted small mb-0">Belum ada yang memilih</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-light mt-3">
                        <div class="d-flex">
                            <i class="bi bi-lightbulb text-warning me-3" style="font-size: 1.2rem;"></i>
                            <div>
                                <h6 class="mb-1">Tips & Panduan</h6>
                                <ul class="mb-0 small">
                                    <li>Ekstrakurikuler yang sudah memiliki pemilih <strong>tidak dapat dihapus</strong>.</li>
                                    <li>Pastikan kuota sesuai dengan kapasitas yang tersedia di sekolah.</li>
                                    <li>Perbarui informasi pembina jika ada perubahan.</li>
                                    <li>Gunakan deskripsi yang jelas untuk menarik minat siswa.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('styles')

@endpush

@push('scripts')

@endpush