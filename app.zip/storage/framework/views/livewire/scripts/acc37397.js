
export function run($wire, $js) {
    document.addEventListener('livewire:initialized', () => {
        // SweetAlert untuk konfirmasi delete
        @this.on('show-delete-confirmation', (event) => {
            const id = event[0].id;
            const name = event[0].name;
            
            Swal.fire({
                title: 'Hapus User',
                text: `Apakah Anda yakin ingin menghapus "${name}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return new Promise((resolve) => {
                        @this.call('deleteConfirmed', id);
                        setTimeout(() => {
                            resolve();
                        }, 1000);
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.isConfirmed) {
                    @this.dispatch('refreshData');
                }
            });
        });

        // SweetAlert dari Livewire dispatch
        @this.on('swal', (event) => {
            const data = event[0];
            Swal.fire({
                icon: data.icon,
                title: data.title,
                text: data.text,
                timer: 3000,
                showConfirmButton: false
            });
        });

        // Auto-focus ke input name ketika modal dibuka
        @this.on('showFormChanged', (value) => {
            if (value) {
                setTimeout(() => {
                    const nameInput = document.querySelector('input[wire\\:model="name"]');
                    if (nameInput) nameInput.focus();
                }, 100);
            }
        });

        // Close modal dengan ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && @this.showForm) {
                @this.call('cancel');
            }
        });
    });

    // Handle SweetAlert dari session flash
    document.addEventListener('DOMContentLoaded', function() {
        @if(session('swal'))
            Swal.fire({
                icon: '{{ session('swal')['icon'] }}',
                title: '{{ session('swal')['title'] }}',
                text: '{{ session('swal')['text'] }}',
                timer: 3000,
                showConfirmButton: false
            });
        @endif
    });
}