
export function run($wire, $js) {
    document.addEventListener('livewire:initialized', () => {
        // SweetAlert untuk konfirmasi delete
        @this.on('show-delete-confirmation', (event) => {
            const id = event[0].id;
            const name = event[0].name;
            
            Swal.fire({
                title: 'Hapus Ekstrakurikuler',
                text: `Apakah Anda yakin ingin menghapus "${name}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return new Promise((resolve) => {
                        @this.call('deleteConfirmed', id);
                        // Beri waktu untuk proses
                        setTimeout(() => {
                            resolve();
                        }, 1000);
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.isConfirmed) {
                    // Refresh halaman setelah konfirmasi
                    @this.dispatch('refresh');
                }
            });
        });

        // Auto-focus ke input nama ketika modal dibuka
        @this.on('showFormChanged', (value) => {
            if (value) {
                setTimeout(() => {
                    const namaInput = document.querySelector('input[wire\\:model="nama"]');
                    if (namaInput) namaInput.focus();
                }, 100);
            }
        });

        // Close modal dengan ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && @this.showForm) {
                @this.call('cancel');
            }
        });

        // Prevent form submission on Enter key in textarea
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.tagName === 'TEXTAREA' && !e.shiftKey) {
                e.preventDefault();
            }
        });
    });

    // Handle SweetAlert dari session flash
    document.addEventListener('DOMContentLoaded', function() {
        @if(session('swal'))
            Swal.fire({
                icon: '{{ session('swal')['icon'] }}',
                title: '{{ session('swal')['title'] }}',
                text: '{{ session('swal')['text'] }}',
                timer: 3000,
                showConfirmButton: false
            });
        @endif
    });
}