<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo e($title ?? config('app.name')); ?></title>

        

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

        <?php echo $__env->make('partials.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </head>
    <body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
        <div class="app-wrapper">
            <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <main class="app-main">
                <?php echo e($slot); ?>

            </main>
            <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <?php echo $__env->make('partials.js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

         <!-- SweetAlert Script -->
        <script>
            // Handle SweetAlert dari session flash
            document.addEventListener('DOMContentLoaded', function() {
                <?php if(session('swal')): ?>
                    Swal.fire({
                        icon: '<?php echo e(session('swal')['icon']); ?>',
                        title: '<?php echo e(session('swal')['title']); ?>',
                        text: '<?php echo e(session('swal')['text']); ?>',
                        timer: 3000,
                        showConfirmButton: false
                    });
                <?php endif; ?>
                
                // Handle semua SweetAlert dari Livewire events
                window.addEventListener('swal', event => {
                    Swal.fire({
                        icon: event.detail.icon,
                        title: event.detail.title,
                        text: event.detail.text,
                        timer: 3000,
                        showConfirmButton: false
                    });
                });
            });
        </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\novibe\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>