<?php

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Ekstrakurikuler;
use App\Models\Vote;
use Illuminate\Validation\Rule;

new class extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    // Properties untuk form
    public $showForm = false;
    public $formType = 'create'; // 'create' or 'edit'
    public $ekstraId = null;

    public $nama = '';
    public $deskripsi = '';
    public $pembina = '';
    public $kuota = 30;

    // Properties untuk search
    public $search = '';
    public $filterStatus = '';

    
    // Properties untuk statistik
    public $stats = [];
    
    // Properties untuk delete
   public $deleteId = null;
   public $deleteName = '';

    protected function rules()
    {
        $rules = [
            'nama' => 'required|string|max:255',
            'deskripsi' => 'required|string|min:10',
            'pembina' => 'required|string|max:255',
            'kuota' => 'required|integer|min:1|max:200',
        ];

        // Untuk edit, tambahkan rule unique kecuali untuk data yang sedang diedit
        if ($this->formType === 'edit') {
            $rules['nama'] = [
                'required',
                'string',
                'max:255',
                Rule::unique('ekstrakurikulers')->ignore($this->ekstraId)
            ];
        } else {
            $rules['nama'] = 'required|string|max:255|unique:ekstrakurikulers,nama';
        }

        return $rules;
    }

    protected $messages = [
        'nama.required' => 'Nama ekstrakurikuler wajib diisi.',
        'nama.unique' => 'Nama ekstrakurikuler sudah ada.',
        'deskripsi.required' => 'Deskripsi wajib diisi.',
        'deskripsi.min' => 'Deskripsi minimal 10 karakter.',
        'pembina.required' => 'Nama pembina wajib diisi.',
        'kuota.required' => 'Kuota wajib diisi.',
        'kuota.integer' => 'Kuota harus berupa angka.',
        'kuota.min' => 'Kuota minimal 1 peserta.',
        'kuota.max' => 'Kuota maksimal 200 peserta.',
    ];

    public function mount()
    {
        $this->loadStats();
    }

    private function loadStats()
    {
        $this->stats = [
            'total' => Ekstrakurikuler::count(),
            'totalKuota' => Ekstrakurikuler::sum('kuota'),
            'totalPemilih' => Vote::count(),
            'persentaseTerisi' => Ekstrakurikuler::sum('kuota') > 0 ? 
                round((Vote::count() / Ekstrakurikuler::sum('kuota')) * 100, 1) : 0,
        ];
    }

    // Reset form
    private function resetForm()
    {
        $this->reset([
            'nama', 'deskripsi', 'pembina', 'kuota',
            'showForm', 'formType', 'ekstraId'
        ]);
        $this->resetErrorBag();
        $this->kuota = 30; // Reset ke default
    }

    // Show create form
    public function showCreateForm()
    {
        $this->resetForm();
        $this->formType = 'create';
        $this->showForm = true;
    }

    // Show edit form
    public function showEditForm($id)
    {
        $this->resetForm();
        
        $ekstra = Ekstrakurikuler::findOrFail($id);
        $this->ekstraId = $ekstra->id;
        $this->nama = $ekstra->nama;
        $this->deskripsi = $ekstra->deskripsi;
        $this->pembina = $ekstra->pembina;
        $this->kuota = $ekstra->kuota;
        
        $this->formType = 'edit';
        $this->showForm = true;
    }

    // Save data
    public function save()
    {
        $this->validate();

        $data = [
            'nama' => $this->nama,
            'deskripsi' => $this->deskripsi,
            'pembina' => $this->pembina,
            'kuota' => $this->kuota,
        ];

        if ($this->formType === 'create') {
            Ekstrakurikuler::create($data);
            $message = 'Ekstrakurikuler berhasil ditambahkan!';
        } else {
            Ekstrakurikuler::find($this->ekstraId)->update($data);
            $message = 'Ekstrakurikuler berhasil diperbarui!';
        }

        $this->resetForm();
        $this->loadStats();
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => $message
        ]);
    }

     // Delete data dengan form submit
    public function deleteEkstrakurikuler($id)
    {
        try {
            $ekstra = Ekstrakurikuler::findOrFail($id);
            $nama = $ekstra->nama;
            
            // Cek apakah ada siswa yang sudah memilih ekstrakurikuler ini
            if ($ekstra->votes()->count() > 0) {
                session()->flash('message', "Tidak dapat menghapus {$nama} karena sudah ada siswa yang memilih.");
                session()->flash('messageType', 'error');
                return;
            }
            
            $ekstra->delete();
            
            $this->loadStats();
            
            session()->flash('message', "Ekstrakurikuler {$nama} berhasil dihapus.");
            session()->flash('messageType', 'success');
            
        } catch (\Exception $e) {
            session()->flash('message', 'Terjadi kesalahan saat menghapus data.');
            session()->flash('messageType', 'error');
        }
    }

    // Cancel form
    public function cancel()
    {
        $this->resetForm();
    }

    // Get filtered data
    public function getEkstrakurikulersProperty()
    {
        return Ekstrakurikuler::query()
            ->withCount('votes')
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('nama', 'like', '%' . $this->search . '%')
                      ->orWhere('pembina', 'like', '%' . $this->search . '%')
                      ->orWhere('deskripsi', 'like', '%' . $this->search . '%');
                });
            })
            ->when($this->filterStatus, function ($query) {
                if ($this->filterStatus === 'penuh') {
                    $query->havingRaw('votes_count >= kuota');
                } elseif ($this->filterStatus === 'tersedia') {
                    $query->havingRaw('votes_count < kuota AND votes_count > 0');
                } elseif ($this->filterStatus === 'kosong') {
                    $query->havingRaw('votes_count = 0');
                } elseif ($this->filterStatus === 'hampir_penuh') {
                    $query->havingRaw('votes_count >= kuota * 0.8 AND votes_count < kuota');
                }
            })
            ->orderBy('nama')
            ->paginate(10);
    }

    // Hitung persentase kuota
    public function getPersentaseKuota($ekstra)
    {
        if ($ekstra->kuota == 0) return 0;
        
        $pemilih = $ekstra->votes_count;
        return round(($pemilih / $ekstra->kuota) * 100, 1);
    }

    // Get status kuota
    public function getStatusKuota($ekstra)
    {
        $persentase = $this->getPersentaseKuota($ekstra);
        
        if ($persentase >= 100) {
            return ['label' => 'Penuh', 'color' => 'danger', 'icon' => 'bi-x-circle'];
        } elseif ($persentase >= 80) {
            return ['label' => 'Hampir Penuh', 'color' => 'warning', 'icon' => 'bi-exclamation-triangle'];
        } elseif ($ekstra->votes_count > 0) {
            return ['label' => 'Tersedia', 'color' => 'success', 'icon' => 'bi-check-circle'];
        } else {
            return ['label' => 'Belum Ada Pemilih', 'color' => 'secondary', 'icon' => 'bi-clock'];
        }
    }

    // Get sisa kuota
    public function getSisaKuota($ekstra)
    {
        return max(0, $ekstra->kuota - $ekstra->votes_count);
    }

    // Refresh data
    public function refreshData()
    {
        $this->loadStats();
        $this->dispatch('swal', [
            'icon' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Data telah diperbarui.'
        ]);
    }

    public function render()
    {
        return view('pages::admin.⚡ekstramanage', [
            'ekstrakurikulers' => $this->ekstrakurikulers,
        ])->layout('layouts::app')->title('Kelola Ekstrakurikuler');
    }
};
?>

<div>
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex p-3 justify-content-between align-items-center">
                <div>
                    <h2 class="fw-bold">
                        <i class="bi bi-trophy"></i> Kelola Ekstrakurikuler
                    </h2>
                    <p class="text-muted">Management data ekstrakurikuler SMK Metland Cibitung</p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary" wire:click="refreshData">
                        <i class="bi bi-arrow-clockwise"></i> Refresh
                    </button>
                    <button class="btn btn-primary" wire:click="showCreateForm">
                        <i class="bi bi-plus-circle"></i> Tambah Ekstrakurikuler
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats -->
    <div class="row mb-4 p-3">
        <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Ekstrakurikuler</h6>
                            <h2 class="mb-0"><?php echo e($stats['total'] ?? 0); ?></h2>
                        </div>
                        <i class="bi bi-collection" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Kuota</h6>
                            <h2 class="mb-0"><?php echo e($stats['totalKuota'] ?? 0); ?></h2>
                        </div>
                        <i class="bi bi-people-fill" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Pemilih</h6>
                            <h2 class="mb-0"><?php echo e($stats['totalPemilih'] ?? 0); ?></h2>
                        </div>
                        <i class="bi bi-check-circle-fill" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Terisi</h6>
                            <h2 class="mb-0"><?php echo e($stats['persentaseTerisi'] ?? 0); ?>%</h2>
                        </div>
                        <i class="bi bi-percent" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search and Filter -->
    <div class="card mb-2 shadow-sm">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="bi bi-search"></i>
                        </span>
                        <input type="text" 
                               class="form-control" 
                               placeholder="Cari nama, pembina, atau deskripsi..." 
                               wire:model.live.debounce.300ms="search">
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select" wire:model.live="filterStatus">
                        <option value="">Semua Status</option>
                        <option value="tersedia">Tersedia</option>
                        <option value="hampir_penuh">Hampir Penuh</option>
                        <option value="penuh">Penuh</option>
                        <option value="kosong">Belum Ada Pemilih</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <div class="d-flex justify-content-end">
                        <span class="text-muted me-2">
                            <?php echo e($ekstrakurikulers->total()); ?> data ditemukan
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Form Modal -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showForm): ?>
        <!-- Delete Confirmation Modal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" wire:ignore.self>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title">
                            <i class="bi bi-exclamation-triangle"></i> Konfirmasi Hapus
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah Anda yakin ingin menghapus <strong id="deleteItemName"></strong>?</p>
                        <p class="text-danger small">
                            <i class="bi bi-info-circle"></i> 
                            Data yang sudah dihapus tidak dapat dikembalikan.
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-circle"></i> Batal
                        </button>
                        <button type="button" class="btn btn-danger" id="confirmDeleteBtn">
                            <i class="bi bi-trash"></i> Ya, Hapus
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade show d-block" tabindex="-1" style="background-color: rgba(0,0,0,0.5);">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">
                            <i class="bi bi-trophy"></i>
                            <?php echo e($formType === 'create' ? 'Tambah' : 'Edit'); ?> Ekstrakurikuler
                        </h5>
                        <button type="button" class="btn-close btn-close-white" wire:click="cancel"></button>
                    </div>
                    <div class="modal-body">
                        <form wire:submit.prevent="save">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nama Ekstrakurikuler <span class="text-danger">*</span></label>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           wire:model="nama"
                                           placeholder="Contoh: Pramuka, PMR, Basket"
                                           autofocus>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Pembina <span class="text-danger">*</span></label>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['pembina'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           wire:model="pembina"
                                           placeholder="Nama pembina">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['pembina'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Deskripsi <span class="text-danger">*</span></label>
                                <textarea class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          wire:model="deskripsi" 
                                          rows="4"
                                          placeholder="Deskripsi kegiatan ekstrakurikuler..."></textarea>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <small class="text-muted">Minimal 10 karakter</small>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Kuota Peserta <span class="text-danger">*</span></label>
                                    <input type="number" 
                                           class="form-control <?php $__errorArgs = ['kuota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           wire:model="kuota"
                                           min="1" 
                                           max="200">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['kuota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <small class="text-muted">Maksimal 200 peserta</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Preview</label>
                                    <div class="border rounded p-3 bg-light">
                                        <small class="text-muted d-block mb-1">Informasi:</small>
                                        <div class="d-flex justify-content-between">
                                            <span>Nama:</span>
                                            <span class="fw-semibold"><?php echo e($nama ?: 'Belum diisi'); ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <span>Kuota:</span>
                                            <span class="fw-semibold"><?php echo e($kuota); ?> peserta</span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <span>Pembina:</span>
                                            <span class="fw-semibold"><?php echo e($pembina ?: 'Belum diisi'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2 mt-4">
                                <button type="button" class="btn btn-secondary" wire:click="cancel">
                                    <i class="bi bi-x-circle"></i> Batal
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Simpan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Data Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ekstrakurikulers->isEmpty()): ?>
                <div class="text-center py-5">
                    <i class="bi bi-trophy" style="font-size: 4rem; color: #e9ecef;"></i>
                    <h4 class="mt-3">Tidak ada data</h4>
                    <p class="text-muted">Belum ada data ekstrakurikuler.</p>
                    <button class="btn btn-primary" wire:click="showCreateForm">
                        <i class="bi bi-plus-circle"></i> Tambah Data Pertama
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th width="50">#</th>
                                <th>Nama Ekstrakurikuler</th>
                                <th>Pembina</th>
                                <th>Kuota</th>
                                <th>Pemilih</th>
                                <th>Status</th>
                                <th width="120" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $ekstrakurikulers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ekstra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <?php
                                    $status = $this->getStatusKuota($ekstra);
                                    $persentase = $this->getPersentaseKuota($ekstra);
                                    $sisaKuota = $this->getSisaKuota($ekstra);
                                ?>
                                <tr>
                                    <td><?php echo e($ekstrakurikulers->firstItem() + $index); ?></td>
                                    <td>
                                        <div>
                                            <strong class="d-block"><?php echo e($ekstra->nama); ?></strong>
                                            <small class="text-muted"><?php echo e(Str::limit($ekstra->deskripsi, 60)); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-info bg-opacity-10 text-info border border-info">
                                            <?php echo e($ekstra->pembina); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div>
                                            <span class="fw-semibold"><?php echo e($ekstra->kuota); ?></span>
                                            <small class="text-muted d-block">peserta</small>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="progress flex-grow-1 me-2" style="height: 8px; min-width: 60px;">
                                                <div class="progress-bar bg-<?php echo e($status['color']); ?>" 
                                                     role="progressbar" 
                                                     style="width: <?php echo e(min($persentase, 100)); ?>%">
                                                </div>
                                            </div>
                                            <div class="text-end">
                                                <span class="fw-semibold"><?php echo e($ekstra->votes_count); ?></span>
                                                <small class="text-muted d-block"><?php echo e($persentase); ?>%</small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($status['color']); ?>">
                                            <i class="<?php echo e($status['icon']); ?> me-1"></i><?php echo e($status['label']); ?>

                                        </span>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sisaKuota > 0 && $persentase < 100): ?>
                                            <small class="d-block text-muted">Sisa: <?php echo e($sisaKuota); ?></small>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-primary" 
                                                    wire:click="showEditForm(<?php echo e($ekstra->id); ?>)"
                                                    title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ekstra->votes_count == 0): ?>
                                                <form wire:submit.prevent="deleteEkstrakurikuler(<?php echo e($ekstra->id); ?>)" 
                                                    onsubmit="return confirm('Apakah Anda yakin ingin menghapus <?php echo e($ekstra->nama); ?>?')"
                                                    style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" 
                                                            class="btn btn-outline-danger" 
                                                            title="Hapus">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn btn-outline-secondary" 
                                                        title="Tidak dapat dihapus karena sudah ada pemilih"
                                                        disabled>
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <p class="text-muted mb-0">
                            Menampilkan <?php echo e($ekstrakurikulers->firstItem()); ?> - <?php echo e($ekstrakurikulers->lastItem()); ?> 
                            dari <?php echo e($ekstrakurikulers->total()); ?> data
                        </p>
                    </div>
                    <div>
                        <?php echo e($ekstrakurikulers->links()); ?>

                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <!-- Legend and Information -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-info">
                <div class="card-header bg-info bg-opacity-10 border-info">
                    <h5 class="mb-0">
                        <i class="bi bi-info-circle text-info"></i> Informasi & Panduan
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-success me-2">
                                    <i class="bi bi-check-circle"></i> Tersedia
                                </span>
                                <div>
                                    <small class="fw-semibold">Tersedia</small>
                                    <p class="text-muted small mb-0">Masih menerima peserta baru</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-warning me-2">
                                    <i class="bi bi-exclamation-triangle"></i> Hampir Penuh
                                </span>
                                <div>
                                    <small class="fw-semibold">Hampir Penuh</small>
                                    <p class="text-muted small mb-0">Kuota terisi ≥80%</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-danger me-2">
                                    <i class="bi bi-x-circle"></i> Penuh
                                </span>
                                <div>
                                    <small class="fw-semibold">Penuh</small>
                                    <p class="text-muted small mb-0">Kuota sudah terpenuhi</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-secondary me-2">
                                    <i class="bi bi-clock"></i> Belum Ada
                                </span>
                                <div>
                                    <small class="fw-semibold">Belum Ada Pemilih</small>
                                    <p class="text-muted small mb-0">Belum ada yang memilih</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-light mt-3">
                        <div class="d-flex">
                            <i class="bi bi-lightbulb text-warning me-3" style="font-size: 1.2rem;"></i>
                            <div>
                                <h6 class="mb-1">Tips & Panduan</h6>
                                <ul class="mb-0 small">
                                    <li>Ekstrakurikuler yang sudah memiliki pemilih <strong>tidak dapat dihapus</strong>.</li>
                                    <li>Pastikan kuota sesuai dengan kapasitas yang tersedia di sekolah.</li>
                                    <li>Perbarui informasi pembina jika ada perubahan.</li>
                                    <li>Gunakan deskripsi yang jelas untuk menarik minat siswa.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .progress {
        min-width: 60px;
    }
    .btn-group-sm .btn {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    .modal {
        backdrop-filter: blur(3px);
    }
    .badge {
        font-size: 0.75em;
    }
    .table td {
        vertical-align: middle;
    }
    .form-control:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('livewire:initialized', () => {
        // SweetAlert untuk konfirmasi delete
        window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('show-delete-confirmation', (event) => {
            const id = event[0].id;
            const name = event[0].name;
            
            Swal.fire({
                title: 'Hapus Ekstrakurikuler',
                text: `Apakah Anda yakin ingin menghapus "${name}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return new Promise((resolve) => {
                        window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('deleteConfirmed', id);
                        // Beri waktu untuk proses
                        setTimeout(() => {
                            resolve();
                        }, 1000);
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.isConfirmed) {
                    // Refresh halaman setelah konfirmasi
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').dispatch('refresh');
                }
            });
        });

        // Auto-focus ke input nama ketika modal dibuka
        window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('showFormChanged', (value) => {
            if (value) {
                setTimeout(() => {
                    const namaInput = document.querySelector('input[wire\\:model="nama"]');
                    if (namaInput) namaInput.focus();
                }, 100);
            }
        });

        // Close modal dengan ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && window.Livewire.find('<?php echo e($_instance->getId()); ?>').showForm) {
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('cancel');
            }
        });

        // Prevent form submission on Enter key in textarea
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.tagName === 'TEXTAREA' && !e.shiftKey) {
                e.preventDefault();
            }
        });
    });

    // Handle SweetAlert dari session flash
    document.addEventListener('DOMContentLoaded', function() {
        <?php if(session('swal')): ?>
            Swal.fire({
                icon: '<?php echo e(session('swal')['icon']); ?>',
                title: '<?php echo e(session('swal')['title']); ?>',
                text: '<?php echo e(session('swal')['text']); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\novibe\laravel\resources\views/pages/admin/⚡ekstramanage.blade.php ENDPATH**/ ?>